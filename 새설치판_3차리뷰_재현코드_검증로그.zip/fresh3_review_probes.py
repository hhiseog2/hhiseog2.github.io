"""Offline probes for uiux-fresh-install.zip. Uses temporary data only."""
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import threading
from unittest.mock import patch
from urllib.parse import urlsplit

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent/'review-fresh-install'/'uiux'
for app in ['dc-ai-coach','motion-studio','site-style']:
    sys.path.insert(0,str(ROOT/app))
from aibot import tg_pair
from aibot.db import DB
from motionstudio import account, profile, home
from motionstudio.jobs import JobStore
from motionstudio.console import Console
from sitestyle import references, ref_evidence, observe_actions

results=[]
def record(probe, **data):results.append({'probe':probe,**data})
points=[{'t_ms': t, 'els': {'#panel': {'h': height}}} for t,height in [(0,100),(100,150),(200,100),(300,100)]]
record('settle_before_later_change', samples=[{'t_ms':p['t_ms'],'height':p['els']['#panel']['h']} for p in points],
       reported=observe_actions._settle(points,'#panel',['h']),expected_sample_interval=[100,200])
base=Path(__file__).resolve().parent/'fresh3-probe-data'
base.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir=base) as d:
    tmp=Path(d).resolve()
    db=DB(tmp/'coach.db')
    try:
        db.kv_set(tg_pair.OFFSET,900000)
        class NewBot:
            def __init__(self):self.queue=[];self.offsets=[]
            def get_updates(self,offset,timeout=0):
                self.offsets.append(offset)
                if offset==-1:return self.queue[-1:]
                self.queue=[x for x in self.queue if x['update_id']>=offset]
                return list(self.queue)
        tg=NewBot()
        start=tg_pair.skip_backlog(tg,db)
        tg.queue=[{'update_id':100,'message':{'text':'/start 123456'}}]
        got=tg.get_updates(start)
        record('new_bot_reuses_old_offset', retained_offset=start, new_update_id=100,
               received=got, pending_after_poll=len(tg.queue),real_service_called=False)
    finally:db.close()

    settings=tmp/'motion-settings'
    with patch.dict(os.environ,{account.ENV_HOME:str(settings)}):
        account.set_budget(20,3)
        original_rename=os.rename
        signal=threading.Event();done=threading.Event();reservations=[];errors=[]
        def other_window():
            signal.wait(10)
            try:reservations.append(account.reserve(1,'offline concurrent reservation'))
            except Exception as e:errors.append(type(e).__name__)
            finally:done.set()
        thread=threading.Thread(target=other_window);thread.start()
        def rename_after_reservation(src,dst):
            # Check exact absolute targets stay in the temporary review directory.
            Path(src).resolve().relative_to(tmp);Path(dst).resolve().relative_to(tmp)
            signal.set()
            if not done.wait(10):raise RuntimeError('probe timed out')
            return original_rename(src,dst)
        with patch.object(profile.os,'rename',side_effect=rename_after_reservation):
            moved=profile.start_fresh('offline-race')
        thread.join(10)
        moved_rows=[json.loads(x) for x in (moved/'spend.jsonl').read_text(encoding='utf-8').splitlines()]
        record('reset_races_new_reservation', reservation_created=bool(reservations),worker_errors=errors,
               active_profile_reservations=len(account.open_reservations()),
               moved_reservation_rows=sum(x['kind']=='reserve' for x in moved_rows),
               settings_moved=True,real_service_called=False)

        settings.mkdir(exist_ok=True)
        (settings/'spend.jsonl').write_bytes(b'\xff\xfe\x80')
        inputs=[]
        def ask(prompt):inputs.append(prompt);return '0'
        try:
            code=home.run(JobStore(tmp/'jobs'),tmp/'output',Console(ask=ask,out=lambda *a:None))
            record('invalid_ledger_home',exit_code=code,exception=None,menu_prompts=len(inputs))
        except Exception as e:
            record('invalid_ledger_home',exception=type(e).__name__,menu_prompts=len(inputs))

    # Reuse the shipped schema-valid fixture maker, with an ambiguous URL as the only variation.
    sys.path.insert(0,str(ROOT/'site-style'/'tests'))
    from test_reference_evidence import make_record, write_run
    lib=tmp/'references';lib.mkdir();(lib/'observations').mkdir()
    shutil.copyfile(ROOT/'site-style'/'references'/'library.json',lib/'library.json')
    url='https://www.apple.com:443@unrelated.example/'
    rid='desktop-reduce-008';runid='ref-offline-host'
    write_run(lib,runid,url,[make_record(runid,rid,'reduced_motion',url)],brand='apple')
    errs=references.link('apple-reduce-motion-01',[runid+'#'+rid],'offline controlled URL test',lib_dir=lib)
    loaded=references.load(lib)
    record('userinfo_confuses_brand_host',actual_host=urlsplit(url).hostname,parsed_host=ref_evidence.host(url),
           link_errors=errs,status=loaded.status('apple-reduce-motion-01'),real_browser_or_site_used=False)

Path(__file__).with_name('fresh3-probe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
